# Common utilities for ArangoDB Entity Resolution scripts
